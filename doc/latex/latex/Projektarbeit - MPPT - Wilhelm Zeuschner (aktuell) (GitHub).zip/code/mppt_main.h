/*
Global variable declarations
*/

#ifndef __MPPT_MAIN
#define __MPPT_MAIN

//Measurements of voltage and power on the in- and output
//volatile float in_voltage, in_power, out_voltage;

//PWM value
//volatile int boost_pwm_val;

#endif