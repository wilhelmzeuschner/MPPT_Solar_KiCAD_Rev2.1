/*
Configuration file for the I²C devices
*/

//Addresses
//#define EEPROM_ADDR     
//#define INA_ADDR        